package com.example.recycleproject;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;


//java file for main activity//
public class MainActivity extends AppCompatActivity {
    private ArrayList<exampleItem> exampleItems;
    private RecyclerView mrecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    ImageView Monitor;
    ImageView Exit;

    // User Session Manager Class
    UserSessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // User Session Manager
        session = new UserSessionManager(getApplicationContext());

        Toast.makeText(getApplicationContext(),
                "User Login Status: " + session.isUserLoggedIn(),
                Toast.LENGTH_LONG).show();


        // get user data from session
        HashMap<String, String> user = session.getUserDetails();

        // get name
        String name = user.get(UserSessionManager.KEY_EMAIL);

        // get email
        String email = user.get(UserSessionManager.KEY_PASSWORD);

        Exit = (ImageView) findViewById(R.id.exit);
        Exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Clear the User session data
                // and redirect user to LoginActivity
                session.logoutUser();
            }
        });

        //creating and adding example type array//
        exampleItems = new ArrayList<>();
        exampleItems.add(new exampleItem("Slotted Head Machine Screws-DIN 84A", "Location: Wing 'A' 6th floor,Rock#14,Bin1"));
        exampleItems.add(new exampleItem("Self-clinching Nuts-DXA 234", "Location: Wing 'A' 6th floor,Rock#13,Bin2"));
        exampleItems.add(new exampleItem("Slotted Screws-MAT 214A", "Location: Wing 'A' 6th floor,Rock#12,Bin3"));
        exampleItems.add(new exampleItem("Slotted Head Machine Screws-DIN 84A", "Location: Wing 'A' 6th floor,Rock#14,Bin4"));
        exampleItems.add(new exampleItem("Self-clinching Nuts-DXA 234", "Location: Wing 'A' 6th floor,Rock#13,Bin5"));
        exampleItems.add(new exampleItem("Slotted Screws-MAT 214A", "Location: Wing 'A' 6th floor,Rock#12,Bin6"));


        //get hold of elemnts in mainActivity//
        mrecyclerView = findViewById(R.id.relative_layout);
        mrecyclerView.setHasFixedSize(true);
        mLayoutManager = new LinearLayoutManager(this);
        mAdapter = new ExampleAdapter(exampleItems);
        mrecyclerView.setLayoutManager(mLayoutManager);
        mrecyclerView.setAdapter(mAdapter);

        //to swipe item//
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.RIGHT | ItemTouchHelper.LEFT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            //action on swipe//
            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                viewHolder.getAdapterPosition();
                int position = viewHolder.getAdapterPosition();
                exampleItems.remove(position);
                mAdapter.notifyItemRemoved(position);
                Toast.makeText(MainActivity.this, "Record Deleted", Toast.LENGTH_SHORT).show();
            }

        }).attachToRecyclerView(mrecyclerView);

        //actin for on click of moniter icon//
        Monitor = (ImageView) findViewById(R.id.moniter);
        Monitor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(MainActivity.this, moniter.class);
                startActivity(in);
            }
        });


    }

}
