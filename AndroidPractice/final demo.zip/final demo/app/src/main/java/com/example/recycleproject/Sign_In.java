package com.example.recycleproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

//java file for signin activity//
public class Sign_In extends AppCompatActivity {
    TextView sign1;
    EditText email1, password1, confirm_password;
    Button submit;
    data_list datalist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign__in);

        //get hold og elements in activity//
        sign1 = (TextView) findViewById(R.id.si);
        email1 = findViewById(R.id.emal);
        password1 = findViewById(R.id.passwo);
        confirm_password = findViewById(R.id.password1);
        submit = findViewById(R.id.subm);

        datalist = (data_list) getApplicationContext();

        //action for click of sign in option//
        sign1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        //action for click of registration/
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                compare();//method to verify password//

            }
        });

    }

    //method to verify password//
    void compare() {
        boolean ifvalid = true;

        //checking weather all field is field and emil pattern is match//
        if (isEmpty(email1)) {
            email1.setError("Enter Email Address to Login!");
            ifvalid = false;
        } else {
            if (!isEmail(email1)) {
                email1.setError("Enter Valid Email Address");
                ifvalid = false;
            }
        }

        if (isEmpty(password1)) {
            password1.setError("Enter Password!");
        }

        if (isEmpty(confirm_password)) {
            confirm_password.setError("Enter Password!");
        }

        if (!password1.getText().toString().equals(confirm_password.getText().toString())) {
            Toast t = Toast.makeText(this, "Passwords are not matching", Toast.LENGTH_LONG);
            t.show();
            ifvalid = false;
        }

        //finely verify password and register complete//
        if (ifvalid) {
            String p1 = email1.getText().toString();
            String p2 = password1.getText().toString();
            datalist.setd(p1, p2);
            Toast t = Toast.makeText(this, "Signed Up done", Toast.LENGTH_LONG);
            t.show();
            finish();
        } else {

            email1.setText("");
            password1.setText("");
            confirm_password.setText("");
        }
    }

    //email pattern check//
    boolean isEmail(EditText text) {
        CharSequence email = text.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }

    //field state check//
    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }


}
