package com.example.recycleproject;

//creating use defined data type//
public class item {
    private int imgResId;
    private String title;//bin name
    private String desc;//location
    private String comments;
    private String dimension;
    private String bname;
    private String rfid;
    private String iname;
    private String dim;
    private String material;
    private String weight;
    private String status;

    public item(int imgResId, String title, String desc, String comments, String dimension, String bname, String rfid, String iname, String dim,String material,String weight,String status) {
        this.imgResId = imgResId;
        this.title = title;
        this.desc = desc;
        this.comments = comments;
        this.dimension = dimension;
        this.bname = bname;
        this.rfid = rfid;
        this.iname = iname;
        this.dim = dim;
        this.material=material;
        this.weight=weight;
        this.status=status;
    }

    public int getImgResId() {
        return imgResId;
    }

    public String getTitle() {
        return title;
    }

    public String getDesc() {
        return desc;
    }

    public String getComments() {
        return comments;
    }

    public String getDimension() {
        return dimension;
    }

    public String getBintype() {
        return bname;
    }

    public String getRfid() {
        return rfid;
    }

    public String getIname() {
        return iname;
    }

    public String getDim() {
        return dim;
    }

    public String getMaterial(){return  material;}

    public String getWeight(){return weight;}

    public String getStatus(){return status;}
}

