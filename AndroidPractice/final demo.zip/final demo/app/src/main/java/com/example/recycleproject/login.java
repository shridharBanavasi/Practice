package com.example.recycleproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static android.service.autofill.Validators.or;


//java file foe login activity//
public class login extends AppCompatActivity {
    Button button;
    EditText text1, text2;
    TextView submit;
    int count = 5;
    data_list datalist;

    // User Session Manager Class
    UserSessionManager session;

    //oncreatin of activity//
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Session class instance
        session = new UserSessionManager(getApplicationContext());

        Toast.makeText(getApplicationContext(),
                "User Login Status: " + session.isUserLoggedIn(),
                Toast.LENGTH_LONG).show();

        datalist = (data_list) getApplicationContext();

        //geting variable for elemnts in activity//
        button = (Button) findViewById(R.id.submit);
        text1 = (EditText) findViewById(R.id.email);
        text2 = (EditText) findViewById(R.id.password);
        submit = (TextView) findViewById(R.id.signup);

        // Check user login (this is the important point)
        // If User is not logged in , This will redirect user to LoginActivity
        // and finish current activity from activity stack.
        if (session.checkLogin())
            finish();

        //actin for click of the login button//
        button.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                checkinfo();//method written bellow//
            }
        });

        //actin for click of the new register//
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent s = new Intent(login.this, Sign_In.class);
                startActivity(s);
            }
        });
    }

    //method to verife login//
    void checkinfo() {
        boolean isvalid = true;
        //check if email fild is empty//
        if (isEmpty(text1)) {
            text1.setError("Enter Email Address to Login!");
            isvalid = false;
        } else {
            if (!isEmail(text1)) {
                text1.setError("Enter Valid Email Address");//check valid email formate//
                isvalid = false;
            }
        }

        //check is password filed is emptoy//
        if (isEmpty(text2)) {
            text2.setError("Enter Password!");
        }

        //athenthication//
        if (isvalid) {
            String email = text1.getText().toString();
            String passw = text2.getText().toString();
            if (text1.getText().toString().equals("admin@matriot.com") && text2.getText().toString().equals("1234")) {
                session.createUserLoginSession(email,
                        passw);

                // Starting MainActivity
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                // Add new Flag to start new Activity
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);

                finish();
            } else if (datalist.User_info.containsKey(email)) {
                if (text2.getText().toString().equals(datalist.User_info.get(email))) {
                    session.createUserLoginSession(email,
                            passw);

                    // Starting MainActivity
                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

                    // Add new Flag to start new Activity
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);

                    finish();
                } else {
                    Toast t = Toast.makeText(this, "Password is incorrect", Toast.LENGTH_LONG);
                    t.show();
                }

            } else {
                Toast t = Toast.makeText(this, "Wrong Email or Password! You Got " + (count - 1) + " Chances", Toast.LENGTH_LONG);
                t.show();
                count--;
                text1.setText("");
                text2.setText("");
                if (count == 0) {
                    finish();
                }
            }

        }
    }

    //method to find emailfoemate//
    boolean isEmail(EditText text) {
        CharSequence email = text.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }

    //method to find text field is empty//
    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }
}
