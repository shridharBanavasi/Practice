package com.example.recycleproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import static com.example.recycleproject.moniter.EXTRA_BNAME;
import static com.example.recycleproject.moniter.EXTRA_CREATOR;
import static com.example.recycleproject.moniter.EXTRA_DIM;
import static com.example.recycleproject.moniter.EXTRA_DIMENSION;
import static com.example.recycleproject.moniter.EXTRA_INAME;
import static com.example.recycleproject.moniter.EXTRA_LIKES;
import static com.example.recycleproject.moniter.EXTRA_MATERIAL;
import static com.example.recycleproject.moniter.EXTRA_RFID;
import static com.example.recycleproject.moniter.EXTRA_STATUS;
import static com.example.recycleproject.moniter.EXTRA_TITLE;
import static com.example.recycleproject.moniter.EXTRA_URL;
import static com.example.recycleproject.moniter.EXTRA_WEIGHT;

public class details extends AppCompatActivity {

    TextView mDetails;
    ConstraintLayout mBinDetails;
    TextView mItem;
    ConstraintLayout mItemDetails;
    TextView mBinName;
    TextView mLocation;
    ImageView mHome;
    ImageView mMoniter;
    ImageView mExit;
    TextView mDimension;
    TextView mBname;
    TextView mRfid;
    TextView mpers;
    TextView mIname;
    TextView mdim;
    TextView mMaterial;
    TextView mWeight;
    TextView mStatus;
    int i=0;
    int j=0;

    UserSessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        session = new UserSessionManager(getApplicationContext());

        mDetails = (TextView) findViewById(R.id.a);
        mBinDetails = (ConstraintLayout) findViewById(R.id.bindetails);
        mHome = (ImageView) findViewById(R.id.mhome);
        mMoniter = (ImageView) findViewById(R.id.mmoniter);
        mItemDetails = (ConstraintLayout) findViewById(R.id.itemdetails);
        mBinName = (TextView) findViewById(R.id.binname);
        mExit = (ImageView) findViewById(R.id.ex);
        mItem = (TextView) findViewById(R.id.b);
        mItemDetails = (ConstraintLayout) findViewById(R.id.itemdetails);
        mBinName = (TextView) findViewById(R.id.binname);
        mLocation = (TextView) findViewById(R.id.location);
        mDimension = (TextView) findViewById(R.id.dimension);
        mBname = (TextView) findViewById(R.id.bintype);
        mRfid = (TextView) findViewById(R.id.rfid);
        mpers = (TextView) findViewById(R.id.perc);
        mIname = (TextView) findViewById(R.id.itemname);
        mdim = (TextView) findViewById(R.id.itemdemension);
        mMaterial=(TextView)findViewById(R.id.material);
        mWeight=(TextView)findViewById(R.id.volume);
        mStatus=(TextView)findViewById(R.id.availability);


        final Intent intent = getIntent();
        String titleName = intent.getStringExtra(EXTRA_TITLE);//getting bin name
        String imageUrl = intent.getStringExtra(EXTRA_URL);//getting img
        String binlocation = intent.getStringExtra(EXTRA_CREATOR);//geting location
        String dimension = intent.getStringExtra(EXTRA_DIMENSION);
        String bname = intent.getStringExtra(EXTRA_BNAME);
        String rfid = intent.getStringExtra(EXTRA_RFID);
        String pers = intent.getStringExtra(EXTRA_LIKES);
        String iname = intent.getStringExtra(EXTRA_INAME);
        String dim = intent.getStringExtra(EXTRA_DIM);
        String material=intent.getStringExtra(EXTRA_MATERIAL);
        String weight=intent.getStringExtra(EXTRA_WEIGHT);//getting volume
        String status=intent.getStringExtra(EXTRA_STATUS);//getting avaliability

        mBinName.setText(titleName);
        mLocation.setText(binlocation);
        mDimension.setText(dimension);
        mBname.setText(bname);
        mRfid.setText(rfid);
        mpers.setText(pers);
        mIname.setText(iname);
        mdim.setText(dim);
        mMaterial.setText(material);
        mWeight.setText(weight);
        mStatus.setText(status);


        mHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent m=new Intent(details.this,MainActivity.class);
                startActivity(m);
                finish();
            }
        });

        mMoniter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        mExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                session.logoutUser();
            }
        });


        mDetails.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(i==0){
                    mBinDetails.setVisibility(View.VISIBLE);
                    i=1;
                }else if(i==1){
                    mBinDetails.setVisibility(View.GONE);
                    i=0;
                }
            }
        });

        mItem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(j==0){
                    mItemDetails.setVisibility(View.VISIBLE);
                    j=1;
                }else if(j==1){
                    mItemDetails.setVisibility(View.GONE);
                    j=0;
                }
            }
        });


    }
}
