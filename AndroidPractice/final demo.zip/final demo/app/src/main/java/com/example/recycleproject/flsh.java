package com.example.recycleproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

//flash screen activity// 
public class flsh extends AppCompatActivity {
    private static int Flash_Time_Out = 1500;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flsh);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent flasshi = new Intent(flsh.this, login.class);
                startActivity(flasshi);
                finish();
            }
        }, Flash_Time_Out);
    }
}
