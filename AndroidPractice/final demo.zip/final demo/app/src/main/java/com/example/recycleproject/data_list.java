package com.example.recycleproject;

import android.app.Application;

import java.util.HashMap;
//import java.util.Iterator;

//Used to create user Register info//
public class data_list extends Application {

    private String email;
    private String password;
    HashMap<String, String> User_info = new HashMap<String, String>();
    //Iterator<String> keyIterator; = User_info.keySet().iterator();

    public data_list() {
    }

    ;

    public void setd(String a, String b) {
        this.email = a;
        this.password = b;
        User_info.put(a, b);

    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }
}
