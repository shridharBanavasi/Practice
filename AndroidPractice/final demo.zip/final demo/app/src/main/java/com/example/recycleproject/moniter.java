package com.example.recycleproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

//defined for spac count//
import static com.example.recycleproject.itemAdapter.SPAN_COUNT_ONE;
import static com.example.recycleproject.itemAdapter.SPAN_COUNT_THREE;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


//java file for moniter//
public class moniter extends AppCompatActivity implements itemAdapter.OnItemClickListener{
    public static final String EXTRA_URL = "imageUrl";
    public static final String EXTRA_CREATOR = "creatorName";
    public static final String EXTRA_LIKES = "likeCount";
    public static final String EXTRA_DIMENSION = "dimension";
    public static final String EXTRA_BNAME = "bname";
    public static final String EXTRA_RFID = "rfid";
    public static final String EXTRA_INAME = "iname";
    public static final String EXTRA_DIM = "dim";
    static final String EXTRA_TITLE = "title";
    static final String EXTRA_MATERIAL="material";
    static final String EXTRA_WEIGHT="weight";
    static final String EXTRA_STATUS="status";

    //ArrayList<String> binName= new ArrayList<>();
    //ArrayList<String> binLocation= new ArrayList<>();

    private RecyclerView recyclerView;
    private itemAdapter itemAdapter;
    private GridLayoutManager gridLayoutManager;
    private List<item> items;
    private item q;
    ImageView h;
    ImageView e;
    ImageView t;

    // User Session Manager Class
    UserSessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moniter);

        // User Session Manager
        session = new UserSessionManager(getApplicationContext());

        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        loadRecycleviewData();
        //initItemData();

        h = (ImageView) findViewById(R.id.hom);
        e = (ImageView) findViewById(R.id.ext);
        t = findViewById(R.id.tog);



        gridLayoutManager = new GridLayoutManager(this, SPAN_COUNT_ONE);
        itemAdapter = new itemAdapter(items, gridLayoutManager);
        recyclerView = (RecyclerView) findViewById(R.id.rv);
        recyclerView.setAdapter(itemAdapter);
        recyclerView.setLayoutManager(gridLayoutManager);
        itemAdapter.setOnItemClickListener(moniter.this);



        //to logout//
        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Clear the User session data
                // and redirect user to LoginActivity
                session.logoutUser();
            }
        });

        //action for on click of home //
        h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent in = new Intent(moniter.this, MainActivity.class);
                startActivity(in);
            }
        });



        //action for on click of grid to list vise versa//
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                switchImage();
                switchLayout();
            }
        });
    }

    /*public void get_json(){
        String json;
        try {
            InputStream is=getAssets().open("cbin.json");
            int size=is.available();
            byte[] buffer=new byte[size];
            is.read(buffer);
            is.close();

            json=new String(buffer,"UTF-8");
            JSONArray jsonArray= new JSONArray(json);

            for(int i =0; i<jsonArray.length();i++){
                JSONObject obj=jsonArray.getJSONObject(i);
                JSONArray currDevice=obj.getJSONArray("currDevice");
                JSONObject currentdevice1=currDevice.getJSONObject(0);
                binName.add(currentdevice1.getString("name"));
                binLocation.add(currentdevice1.getString("location"));
                Toast .makeText(getApplicationContext(),binName.toString()+binLocation.toString(),Toast.LENGTH_LONG).show();
            }
        }catch (IOException e){
            e.printStackTrace();
        }catch (JSONException e){
            e.printStackTrace();
        }

    }*/

    //creating data to pass in elements of recycle view//
    /*private void initItemData() {
        items = new ArrayList<>(15);


        for(int i=0;i<3;i++){
            items.add(new item(R.drawable.cbin, binName.get(i), binLocation.get(i), "20%"));
        }

        items.add(new item(R.drawable.cbin, "Bin #1", "Slottedscrews-MAT21A", "20%"));
        items.add(new item(R.drawable.cbin, "Bin #2", "Slotted Bolt-MAT26B", "72%"));
        items.add(new item(R.drawable.cbin, "Bin #3", "Hex Bolts with Hex Nuts-MAT27C", "48%"));
        items.add(new item(R.drawable.cbin, "Bin #4", "Slottedscrews-MAT21A", "20%"));
        items.add(new item(R.drawable.cbin, "Bin #5", "Slotted Bolt-MAT26B", "72%"));
        items.add(new item(R.drawable.cbin, "Bin #6", "Hex Bolts with Hex Nuts-MAT27C", "48%"));
        items.add(new item(R.drawable.cbin, "Bin #7", "Slottedscrews MAT21A", "20%"));
        items.add(new item(R.drawable.cbin, "Bin #8", "Slotted Bolt-MAT26B", "72%"));
        items.add(new item(R.drawable.cbin, "Bin #9", "Hex Bolts with Hex Nuts-MAT27C", "48%"));
        items.add(new item(R.drawable.cbin, "Bin #10", "Slottedscrews MAT21A", "20%"));
        items.add(new item(R.drawable.cbin, "Bin #11", "Slotted Bolt-MAT26B", "72%"));
        items.add(new item(R.drawable.cbin, "Bin #12", "Hex Bolts with Hex Nuts-MAT27C", "48%"));
        items.add(new item(R.drawable.cbin, "Bin #13", "Slottedscrews MAT21A", "20%"));
        items.add(new item(R.drawable.cbin, "Bin #14", "Slotted Bolt-MAT26B", "72%"));
        items.add(new item(R.drawable.cbin, "Bin #15", "Hex Bolts with Hex Nuts-MAT27C", "48%"));
    }*/


    //creating data to pass in elements of recycle view//
    private void loadRecycleviewData(){
        items = new ArrayList<>(15);
        String json;
        try {
            InputStream is=getAssets().open("cbin.json");
            int size=is.available();
            byte[] buffer=new byte[size];
            is.read(buffer);
            is.close();

            json=new String(buffer,"UTF-8");
            JSONArray jsonArray= new JSONArray(json);
            for(int i =0; i<jsonArray.length();i++){
                JSONObject obj=jsonArray.getJSONObject(i);
                JSONObject dev=obj.getJSONObject("currDevice");
                JSONObject cbin = obj.getJSONObject("crateBin");
                JSONObject dimen = cbin.getJSONObject("dimension");
                JSONObject lr = obj.getJSONObject("lastReading");
                JSONObject reading = lr.getJSONObject("reading");
                JSONObject item = obj.getJSONObject("item");
                JSONObject dim = item.getJSONObject("dimension");
                JSONObject last=obj.getJSONObject("lastReading");
                JSONObject read=last.getJSONObject("reading");
                String a;
                if(dim.has("length")){
                    a=dim.getString("length");
                }else{
                    a= dim.getString("thickness");
                }     

                Log.d("dimension", "loadRecycleviewData: dim" + dim.toString());

                q=new item(R.drawable.cbin,
                        dev.getString("name"),
                        dev.getString("location"),
                        percent(cbin.getInt("capacity"),
                                reading.getInt("weight")) + "%",
                        dimen.getString("length") + "*" + dimen.getString("width") + "*" + dimen.getString("height"),
                        cbin.getString("name"),
                        obj.getString("rfId"),
                        item.getString("name"),
                        dim.getString("dia") + "*" + a + dim.getString("uom"
                        ),
                        item.getString("material"),
                        read.getString("weight"),
                        read.getString("status"));

                Log.d("......", "loadRecycleviewData: "+q.toString());
                items.add(q);

            }


        }catch (IOException e){
            e.printStackTrace();
        }catch (JSONException e){
            e.printStackTrace();


        }

    }

    //method to switch btw grid and list//
    private void switchLayout() {
        if (gridLayoutManager.getSpanCount() == SPAN_COUNT_ONE) {
            gridLayoutManager.setSpanCount(SPAN_COUNT_THREE);
        } else {
            gridLayoutManager.setSpanCount(SPAN_COUNT_ONE);
        }
        itemAdapter.notifyItemRangeChanged(0, itemAdapter.getItemCount());
    }

    void switchImage() {
        if (gridLayoutManager.getSpanCount() == SPAN_COUNT_THREE) {
            t.setImageResource(R.drawable.ic_span_3);
        } else {
            t.setImageResource(R.drawable.ic_span_1);
        }
    }

    public void onItemClick(int position) {
        Intent detailIntent = new Intent(this, details.class);
        item clickedItem = items.get(position);
        detailIntent.putExtra(EXTRA_TITLE, clickedItem.getTitle());//putting bin name Bin name
        detailIntent.putExtra(EXTRA_URL, clickedItem.getImgResId());
        detailIntent.putExtra(EXTRA_CREATOR, clickedItem.getDesc());//putting location
        detailIntent.putExtra(EXTRA_LIKES, clickedItem.getComments());
        detailIntent.putExtra(EXTRA_DIMENSION, clickedItem.getDimension());
        detailIntent.putExtra(EXTRA_BNAME, clickedItem.getBintype());
        detailIntent.putExtra(EXTRA_RFID, clickedItem.getRfid());
        detailIntent.putExtra(EXTRA_INAME, clickedItem.getIname());
        detailIntent.putExtra(EXTRA_DIM, clickedItem.getDim());
        detailIntent.putExtra(EXTRA_MATERIAL, clickedItem.getMaterial());
        detailIntent.putExtra(EXTRA_WEIGHT,clickedItem.getWeight());
        detailIntent.putExtra(EXTRA_STATUS,clickedItem.getStatus());


        startActivity(detailIntent);
    }

    public String  percent(int cap, int weg){
        int capcity=cap;
        int weight=weg;
        float c=(float)((weight*100)/capcity);
        return String.valueOf(c);
    }

}
