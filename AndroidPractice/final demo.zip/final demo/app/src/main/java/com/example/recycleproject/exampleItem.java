package com.example.recycleproject;

//creating use defined data type//
public class exampleItem {
    private String mText1;
    private String mText2;

    public exampleItem(String text1,String text2){
        mText1=text1;
        mText2=text2;
    }

    public String getMtext1() {
        return mText1;
    }

    public String getMtext2() {
        return mText2;
    }
}
