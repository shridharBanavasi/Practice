package com.example.primus;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import org.json.JSONObject;

import java.util.concurrent.Delayed;

import io.cine.primus.Primus;

public class MainActivity extends AppCompatActivity {
    private Primus primus;
    private final String PRIMUS_URL = "ws://cbindev.matriotsolutions.com/primus?_primuscb=MDJGszT";
    private JSONObject i=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d("jd", "onCreate: jwjs");

        try {
            primus = Primus.connect(this, PRIMUS_URL);
            Primus.PrimusOpenCallback openCallback = new Primus.PrimusOpenCallback() {


                @Override
                public void onOpen() {
                    Log.d("..................", "onOpen: Websocket open");
                }
            };

            Primus.PrimusDataCallback dataCallback = new Primus.PrimusDataCallback() {
                @Override
                public void onData(JSONObject data) {
                    i=data;
                    //got data
                    Log.d("data getting", "onData: "+i.toString());

                }
            };
            primus.setOpenCallback(openCallback);
            primus.setDataCallback(dataCallback);


        }catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        primus.end();
    }


}
